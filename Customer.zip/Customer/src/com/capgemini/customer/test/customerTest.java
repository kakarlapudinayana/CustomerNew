package com.capgemini.customer.test;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.dao.CustomerDAOImpl;
import com.capgemini.customer.exception.CustomerException;

public class customerTest {

    static CustomerDAOImpl dao;
    static CustomerBean customerbean;

    @BeforeClass
    public static void initialize() {
        dao = new CustomerDAOImpl ();
        customerbean = new CustomerBean();
    }

    @Test
    public void testAddContactBookDetails() throws CustomerException {

        assertNotNull(dao.addCustomer(customerbean));
    }
    
    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Ignore
    @Test
    public void testAddContactBookDetails1() throws CustomerException {
        assertEquals(1001, dao.addCustomer(customerbean));
    }

    /************************************
     * Test case for addEnquiryDetails()
     * 
     ************************************/

    @Test
    public void testAddContactBookDetails2() throws CustomerException {
    	
    	customerbean.setCustomer_name("nayana");
    	customerbean.setAge("17");
    	customerbean.setPhone("1234567890");
    	customerbean.setEmail("nayana47@gmail.com");
    	customerbean.setProduct_name("samsung");
    	
    	
        assertTrue("Data Inserted successfully",
                Integer.parseInt(dao.addCustomer(customerbean)) > 1000);

    }
}