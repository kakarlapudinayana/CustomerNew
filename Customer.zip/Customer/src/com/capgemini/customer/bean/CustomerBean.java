package com.capgemini.customer.bean;

import java.sql.Date;

public class CustomerBean {
	
	private String customer_name;
	private String age;
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getProduct_name() {
		return product_name;
	}
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public Date getPurchase_date() {
		return purchase_date;
	}
	public void setPurchase_date(Date purchase_date) {
		this.purchase_date = purchase_date;
	}
	private String email;
	private String phone;
	private Date purchase_date;
	private String product_name;
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		sb.append("-+-+-+-+Printing Customer Details-+-+-+-+ \n");
		sb.append("Name: " +customer_name +"\n");
		sb.append("Age: " +age +"\n");
		sb.append("Phone Number: "+ phone +"\n");
		sb.append("email: " +email +"\n");
		sb.append("Product name: "+ product_name +"\n");
		return sb.toString();
	}
	
	
	
}
