package com.capgemini.customer.dao;

import java.util.List;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;


public interface ICustomerDAO {
	
	public String addCustomer(CustomerBean customerbean) throws CustomerException;

	public List<CustomerBean> retriveAll()throws CustomerException;
	
	
	public CustomerBean viewCustomerDetails(String customer_id) throws CustomerException;

}
