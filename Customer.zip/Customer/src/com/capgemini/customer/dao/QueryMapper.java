package com.capgemini.customer.dao;

public interface QueryMapper {
	public static final String RETRIVE_ALL_QUERY="SELECT customer_name,age,phone,email,product_name,purchase_date FROM customer";
	public static final String VIEW_Customer_DETAILS_QUERY="SELECT customer_name,age,phone,email,product_name,purchase_date FROM customer WHERE  customer_id=?";
		public static final String INSERT_QUERY="INSERT INTO customer VALUES(cust_seq.NEXTVAL,?,?,?,?,?,SYSDATE)";
		public static final String CustomerID_QUERY_SEQUENCE="SELECT cust_seq.CURRVAL FROM DUAL";

}
