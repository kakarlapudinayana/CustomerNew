package com.capgemini.customer.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;
import com.capgemini.customer.util.DBConnection;


	public class CustomerDAOImpl implements ICustomerDAO{
		Logger logger=Logger.getRootLogger();
		
		public CustomerDAOImpl()
		{
		PropertyConfigurator.configure("resources//log4j.properties");
		
		}
		
		@SuppressWarnings("resource")
		
		public String addCustomer(CustomerBean customerbean) throws CustomerException
		{
			Connection connection = DBConnection.getInstance().getConnection();	
			//creating prepared statement
			PreparedStatement preparedStatement=null;		
			ResultSet resultSet = null;
			
			String customer_id=null;
			
			int queryResult=0;
			try
			{	
				
				preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);

			
				preparedStatement.setString(1, customerbean.getCustomer_name());
				preparedStatement.setString(2, customerbean.getAge());
				preparedStatement.setString(3, customerbean.getPhone());
				preparedStatement.setString(4, customerbean.getEmail());
				preparedStatement.setString(5, customerbean.getProduct_name());
				queryResult=preparedStatement.executeUpdate();
				preparedStatement = connection.prepareStatement(QueryMapper.CustomerID_QUERY_SEQUENCE);
				resultSet=preparedStatement.executeQuery();

				if(resultSet.next())
				{
					customer_id=resultSet.getString(1);
							
				}
		
				if(queryResult==0)
				{
					logger.error("Insertion failed ");
					throw new CustomerException("Inserting enuiry details failed ");

				}
				else
				{
					logger.info("enquiry details added successfully:");
					return customer_id;
				}

			}
			catch(SQLException sqlException)
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new CustomerException("Tehnical problem occured refer log");
			}

			finally
			{
				try 
				{
					//resultSet.close();
					preparedStatement.close();
					connection.close();
				}
				catch (SQLException sqlException) 
				{
					sqlException.printStackTrace();
					logger.error(sqlException.getMessage());
					throw new CustomerException("Error in closing db connection");

				}
			}
			

			
		}

		@Override
		public CustomerBean viewCustomerDetails(String customer_id) throws CustomerException{
			// TODO Auto-generated method stub
			
	Connection connection=DBConnection.getInstance().getConnection();
			
			
			PreparedStatement preparedStatement=null;
			ResultSet resultset = null;
			CustomerBean bean=null;
			
			try
			{
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_Customer_DETAILS_QUERY);
				preparedStatement.setString(1,customer_id);
				resultset=preparedStatement.executeQuery();
				
				if(resultset.next())
				{
					
					
					bean = new CustomerBean();
					bean.setCustomer_name(resultset.getString(1));
					bean.setAge(resultset.getString(2));
					bean.setPhone(resultset.getString(3));
					bean.setEmail(resultset.getString(4));
					bean.setProduct_name(resultset.getString(5));
					bean.setPurchase_date(resultset.getDate(6));
									
				}
				
				if( bean != null)
				{
					logger.info("Details Found Successfully");
					return bean;
				}
				else
				{
					logger.info("Details Not Found Successfully");
					return null;
				}
				
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new CustomerException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultset.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new CustomerException("Error in closing db connection");

				}
			}
			
		}

			@Override
		public List<CustomerBean> retriveAll() throws CustomerException {
			// TODO Aut-generated method stub
			
			
			Connection con=DBConnection.getInstance().getConnection();
			int contactbookCount = 0;
			
			PreparedStatement ps=null;
			ResultSet resultset = null;
			
			List<CustomerBean> bookList=new ArrayList<CustomerBean>();
			try
			{
				ps=con.prepareStatement(QueryMapper.RETRIVE_ALL_QUERY);
				resultset=ps.executeQuery();
				
				while(resultset.next())
				{	
					CustomerBean bean=new CustomerBean();
					
					bean.setCustomer_name(resultset.getString(1));
					bean.setAge(resultset.getString(2));
					bean.setPhone(resultset.getString(3));
					bean.setEmail(resultset.getString(4));
			
					bean.setProduct_name(resultset.getString(5));
					bean.setPurchase_date(resultset.getDate(6));
							bookList.add(bean);
					contactbookCount++;
				}			
				
			} catch (SQLException sqlException) {
				logger.error(sqlException.getMessage());
				throw new CustomerException("Tehnical problem occured. Refer log");
			}
			
			finally
			{
				try 
				{
					//resultset.close();
					ps.close();
					con.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new CustomerException("Error in closing db connection");

				}
			}
			
			if( contactbookCount == 0)
				return null;
			else
				return bookList;
		}	
		}

		
		
		
	
