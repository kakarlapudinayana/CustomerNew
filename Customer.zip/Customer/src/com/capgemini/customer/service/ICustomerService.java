package com.capgemini.customer.service;

import java.util.List;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;



public interface ICustomerService {
	
	public String addCustomer(CustomerBean customerbean) throws CustomerException;

	public List<CustomerBean> retriveAll()throws CustomerException;
	
	
	public CustomerBean viewCustomerDetails(String customer_id) throws CustomerException;

}
