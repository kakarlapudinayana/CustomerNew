package com.capgemini.customer.service;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.dao.CustomerDAOImpl;
import com.capgemini.customer.dao.ICustomerDAO;
import com.capgemini.customer.exception.CustomerException;


public  class CustomerSeviceImpl implements ICustomerService {

	private ICustomerDAO customerDAO;

	public CustomerSeviceImpl() 
	{
		customerDAO = new CustomerDAOImpl();
	}


	public String addCustomer(CustomerBean customerbean) throws CustomerException {
	//	System.out.println("here");
		customerDAO= new CustomerDAOImpl();
	//	System.out.println("AFter");
		String cust_seq;
		//System.out.println("AFter2");
		cust_seq= customerDAO.addCustomer(customerbean);
	//	System.out.println("AFter3");
		return cust_seq;
	}
	
	public CustomerBean viewCustomerDetails(String customer_id) throws CustomerException {
		// TODO Auto-generated method stub
		customerDAO=new CustomerDAOImpl();
		CustomerBean bean=null;
		bean=customerDAO.viewCustomerDetails(customer_id);
		return bean;

	}


	public List<CustomerBean> retriveAll()throws CustomerException{
		// TODO Auto-generated method stub
		customerDAO=new CustomerDAOImpl();
		List<CustomerBean> bookList=null;
		bookList =customerDAO.retriveAll();
		return bookList;

	}

	
	
	public boolean isValidEnquiry(CustomerBean bean) throws CustomerException 
	{
		List<String> validationErrors = new ArrayList<String>();

		
		//Validating contact Number
				if(!(isValidContactNo(bean.getPhone()))){
					validationErrors.add("\n Contact Number Should be in 10 digit \n");
				}
			//Validating email	
				if(!(isValidEmail(bean.getEmail()))) {
					validationErrors.add("\n   CustomerEmail Should Be a valid one with .com extension ! \n");
				}
				
		//Validating customer name
		if(!(isValidCName(bean.getCustomer_name()))) {
			validationErrors.add("\n   CustomerName Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating product name
				if(!(isValidPName(bean.getProduct_name()))) {
					validationErrors.add("\n   Product Name Should Be In Alphabets and minimum 3 characters long ! \n");
				}
		
		
			//Validating Age
				if(!(isValidAge(bean.getAge()))) {
					validationErrors.add("\n   Age should be greater than 15 and less than 100! \n");
				}
				
					
		if(!validationErrors.isEmpty())
			throw new CustomerException(validationErrors +"");
		return false;
	}
	
	
	public boolean isValidAge(String age){
		
		Pattern agePattern=Pattern.compile("^([1-9][0-9])");
		Matcher ageMatcher=agePattern.matcher(age);
			return ageMatcher.matches();
	}
	
public boolean isValidEmail(String email){
		
		Pattern emailPattern=Pattern.compile("^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.(?:[A-Z]{2,}|com|org))*$");
   
		Matcher emailMatcher=emailPattern.matcher(email);
			return emailMatcher.matches();
	}
	
	
	public boolean isValidCName(String getCName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getCName);
		return nameMatcher.matches();
	}

	public boolean isValidPName(String getPName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getPName);
		return nameMatcher.matches();
	}

	public boolean isValidContactNo(String No) {
		Pattern contactPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher contactMatcher=contactPattern.matcher(No);
		return contactMatcher.matches();
	}
public boolean isvalidCustomerId(String customer_id) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(customer_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}






}
