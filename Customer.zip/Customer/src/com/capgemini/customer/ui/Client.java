package com.capgemini.customer.ui;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.customer.bean.CustomerBean;
import com.capgemini.customer.exception.CustomerException;
import com.capgemini.customer.service.CustomerSeviceImpl;
import com.capgemini.customer.service.ICustomerService;


public class Client {
	private static final String customer_id = null;
	static Scanner sc = new Scanner(System.in);
		static ICustomerService customerService = null;
		static CustomerSeviceImpl customerServiceImpl = null;
		static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) throws Exception {
		PropertyConfigurator.configure("resources//log4j.properties");
	CustomerBean customerbean = null;
	String customer_id  =null;
	
	int option =0 ;
	while (true) {
		// showing menu
		System.out.println();
		System.out.println();
		System.out.println("--------Customers Organization--------- ");
		

		System.out.println("1.Enter Customer details ");
		System.out.println("2.View Customer Details");
		System.out.println("3.Retrive all customer Details");
		System.out.println("0.Exit");
		
		
		System.out.println("Select an option:");
		// accepting option

		try {
			option = sc.nextInt();

			switch (option) {

			case 1:

				while (customerbean  == null) {
					customerbean   = populatecustomerbean();
					 System.out.println(customerbean);
				}

				try {
					customerService= new CustomerSeviceImpl();
					customer_id = customerService.addCustomer(customerbean);
				System.out.println("Customer details  has been successfully registered ");
					System.out.println("Customer ID Is: " + customer_id);
					

				} catch (CustomerException customerException) {
					logger.error("exception occured", customerException);
					System.out.println("ERROR : "
							+ customerException.getMessage());
				} finally {
					
					customerService = null;
					customerbean = null;
					customer_id=null;
				}

				break;

			case 2:

				customerServiceImpl = new CustomerSeviceImpl();

				System.out.println("Enter numeric contact book id:");
				customer_id = sc.next();

				while (true) {
					
					if (customerServiceImpl.isvalidCustomerId(customer_id)) {
						
					
						break;
					} else {
						System.err
								.println("Please enter numeric enquiry id only, try again");
						customer_id = sc.next();
					}
				}

				customerbean =getCustomerDetails(customer_id);
						
			
				if (customerbean != null) {
					
					
					System.out.println("Customer Name:"+customerbean.getCustomer_name());
					System.out.println("Age:"+customerbean.getAge());
					System.out.println("Contact No:"+customerbean.getPhone());
					System.out.println("Email id:"+customerbean.getEmail());
					System.out.println("Product Name:"+customerbean.getProduct_name());
					
					
					
				} else {
					System.err
							.println("\n There are no Customer book details associated with Customer  id "
									+ customer_id);
				}

				break;
				
			case 3:

				customerService = new CustomerSeviceImpl();
				try {
					List<CustomerBean> bookList = new ArrayList<CustomerBean>();
					bookList = customerService.retriveAll();

					if (bookList != null) {
						Iterator<CustomerBean> i = bookList.iterator();
						while (i.hasNext()) {
							System.out.println(i.next());
						}
					} else {
						System.out
								.println("Nobody has added a customer details , yet.");
					}

				}

				catch (CustomerException e) {

					System.out.println("Error  :" + e.getMessage());
				}

				break;
				
				
			case 0:

				System.out.print("Thanks for being with us!");
				System.exit(0);
				break;
			default:
				System.out.println("Enter a valid option[0-3]");
			}// end of switch
		}

		catch (InputMismatchException e) {
			sc.nextLine();
			System.err.println("Please enter a numeric value, try again");
	}

	}// end of while
	
	

	}
	
private static CustomerBean populatecustomerbean() {

		
	CustomerBean customerbean = new CustomerBean();

		System.out.println("\nCustomer Details");

		System.out.println("Enter  name: ");
		customerbean.setCustomer_name(sc.next());
		
		System.out.println("Enter Age: ");
		customerbean.setAge(sc.next());
		
		System.out.println("Enter contact number: ");
		customerbean.setPhone(sc.next());
		
	
		
		System.out.println("Enter Email ");
		customerbean.setEmail(sc.next());
		
		System.out.println("Enter product name ");
		customerbean.setProduct_name(sc.next());
		
	
		
		customerServiceImpl = new CustomerSeviceImpl();

        try {
        	customerServiceImpl.isValidEnquiry(customerbean);
			
					return customerbean;
		} catch (CustomerException CustomerException) {
			logger.error("exception occured", CustomerException);
			System.err.println("Invalid data:");
			System.err.println(CustomerException.getMessage() + " \n Try again..");
			System.exit(0);

		}
		return null;

	}
	
	private static CustomerBean getCustomerDetails(String customer_id) {
		CustomerBean customerbean = null;
		customerServiceImpl = new CustomerSeviceImpl();

		try {
			customerbean = customerServiceImpl.viewCustomerDetails(customer_id);
		} catch (CustomerException contactException) {
			logger.error("exception occured ", contactException);
			System.out.println("ERROR : " + contactException.getMessage());
		}

		customerServiceImpl = null;
		return customerbean;
	}

	
}
